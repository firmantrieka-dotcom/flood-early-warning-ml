from flask import Flask, jsonify
import os
import json
import pickle
from datetime import datetime

import pandas as pd
import firebase_admin
from firebase_admin import credentials, db

app = Flask(__name__)

DATABASE_URL = os.getenv("DATABASE_URL", "https://firman-banjir-default-rtdb.asia-southeast1.firebasedatabase.app")

# Firebase credential is stored in Railway Variables as FIREBASE_SERVICE_ACCOUNT_JSON
def init_firebase():
    if firebase_admin._apps:
        return

    service_account_json = os.getenv("FIREBASE_SERVICE_ACCOUNT_JSON")
    if service_account_json:
        cred_dict = json.loads(service_account_json)
        cred = credentials.Certificate(cred_dict)
    else:
        # Local testing only. Do not upload this file publicly to GitHub.
        cred = credentials.Certificate("serviceAccountKey.json")

    firebase_admin.initialize_app(cred, {
        "databaseURL": DATABASE_URL
    })

def tentukan_status(air_hulu, hujan_hulu, air_lokal, hujan_lokal):
    if air_lokal >= 14 or air_hulu >= 240 or hujan_hulu >= 160 or hujan_lokal >= 160:
        return "BAHAYA"
    elif air_lokal >= 12 or air_hulu >= 190 or hujan_hulu >= 100 or hujan_lokal >= 100:
        return "SIAGA"
    elif air_lokal >= 8 or air_hulu >= 130 or hujan_hulu >= 40 or hujan_lokal >= 40:
        return "WASPADA"
    else:
        return "AMAN"

def buat_estimasi(status_final, estimasi_menit):
    if status_final == "BAHAYA":
        return "Air di pemukiman sudah mencapai batas bahaya, banjir sudah terjadi"
    if status_final == "SIAGA":
        return "Potensi banjir tinggi, masyarakat perlu bersiap"
    if status_final == "WASPADA":
        return "Kondisi mulai meningkat, masyarakat perlu waspada"
    return "Kondisi air masih normal dan belum menunjukkan potensi banjir"

def hitung_tren_air_lokal(jumlah_data=5):
    histori = db.reference("/banjir/z_histori").get()
    if not histori:
        return 0

    data = []
    for key, value in histori.items():
        try:
            data.append({
                "key": key,
                "air_lokal": float(value.get("air_lokal", 0))
            })
        except Exception:
            pass

    if len(data) < 2:
        return 0

    data = sorted(data, key=lambda x: x["key"])
    data_terakhir = data[-jumlah_data:]
    selisih_data = len(data_terakhir) - 1
    if selisih_data <= 0:
        return 0

    tren = (data_terakhir[-1]["air_lokal"] - data_terakhir[0]["air_lokal"]) / selisih_data
    return round(max(tren, 0), 3)

def hitung_estimasi_menit(air_lokal, tren_air_lokal):
    batas_bahaya = 14
    if air_lokal >= batas_bahaya:
        return 0
    if tren_air_lokal <= 0:
        return 999
    return round((batas_bahaya - air_lokal) / tren_air_lokal)

with open("model.pkl", "rb") as f:
    model = pickle.load(f)

@app.route("/")
def home():
    return "Flood Early Warning ML is running on Railway"

@app.route("/predict", methods=["GET"])
def predict():
    init_firebase()

    hulu = db.reference("/banjir/hulu").get() or {}
    lokal = db.reference("/banjir/lokal").get() or {}

    air_hulu = float(hulu.get("air", 0))
    hujan_hulu = float(hulu.get("hujan", 0))
    air_lokal = float(lokal.get("air", 0))
    hujan_lokal = float(lokal.get("hujan", 0))

    data_baru = pd.DataFrame([{
        "air_hulu_cm": air_hulu,
        "hujan_hulu_mm": hujan_hulu,
        "air_lokal_cm": air_lokal,
        "hujan_lokal_mm": hujan_lokal
    }])

    prediksi_ml = model.predict(data_baru)[0]
    probabilitas = max(model.predict_proba(data_baru)[0]) * 100

    status_logika = tentukan_status(air_hulu, hujan_hulu, air_lokal, hujan_lokal)
    status_final = "BAHAYA" if status_logika == "BAHAYA" else prediksi_ml

    tren_air_lokal = hitung_tren_air_lokal(5)
    estimasi_menit = hitung_estimasi_menit(air_lokal, tren_air_lokal)
    estimasi = buat_estimasi(status_final, estimasi_menit)

    waktu = datetime.now().strftime("%d-%m-%Y %H:%M:%S")

    hasil_ml = {
        "air_hulu": air_hulu,
        "hujan_hulu": hujan_hulu,
        "air_lokal": air_lokal,
        "hujan_lokal": hujan_lokal,
        "ml_prediksi": prediksi_ml,
        "status_logika": status_logika,
        "status_final": status_final,
        "probabilitas_ml": round(probabilitas, 2),
        "akurasi_model": 100.0,
        "tren_air_lokal_per_menit": tren_air_lokal,
        "estimasi_menit": estimasi_menit,
        "estimasi": estimasi,
        "waktu_prediksi": waktu,
        "sumber_data": "Random Forest Railway + Firebase"
    }

    db.reference("/banjir/ml").set(hasil_ml)
    db.reference("/banjir/status").set(status_final)
    db.reference("/banjir/update").set(waktu)

    return jsonify(hasil_ml)

if __name__ == "__main__":
    port = int(os.getenv("PORT", 8080))
    app.run(host="0.0.0.0", port=port)