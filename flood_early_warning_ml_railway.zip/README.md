# Flood Early Warning ML - Railway

Project ini menjalankan model Random Forest untuk sistem peringatan dini banjir sungai.

## Dataset
- Jumlah data: 500 data
- Skala air hulu: 0 - 270 cm
- Skala air lokal/pemukiman: 0 - 16 cm
- Tipping bucket: 0,2 mm per jungkit
- Status: AMAN, WASPADA, SIAGA, BAHAYA

## Pembagian Data
- Data training: 80%
- Data testing: 20%
- Akurasi uji awal: 100.00%

## Jalankan di Railway
Pastikan file berikut ada:
- app.py
- model.pkl
- requirements.txt
- Procfile

Tambahkan Railway Variables:
- DATABASE_URL
- FIREBASE_SERVICE_ACCOUNT_JSON

Endpoint:
- `/` untuk cek server
- `/predict` untuk membaca Firebase, memprediksi status banjir, dan menulis hasil kembali ke Firebase